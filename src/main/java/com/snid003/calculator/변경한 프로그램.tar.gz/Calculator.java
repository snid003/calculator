package com.snid003.calculator;
import org.springframework.stereotype.Service;
/**
 *dududu
 *@author kimchi
 */
@Service
public class Calculator {
	int mul(int a, int b) {
		return a * b;
	}
}
